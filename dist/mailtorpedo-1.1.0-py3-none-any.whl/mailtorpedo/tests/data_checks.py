text_message1 = """Hello 9d18d2,

This is a demo text snippet. It contains variables. 
So the mail body will be changed for each individual.

This message was sent to 5ce15191, aged 31 
If you are not the recipient, reply to this email.

Thank you
"""

text_message2 = """Hello 6a1878,

This is a demo text snippet. It contains variables. 
So the mail body will be changed for each individual.

This message was sent to 68be354e, aged 38 
If you are not the recipient, reply to this email.

Thank you
"""

text_message3 = """Hello 66f91e,

This is a demo text snippet. It contains variables. 
So the mail body will be changed for each individual.

This message was sent to 102f8b25, aged 21 
If you are not the recipient, reply to this email.

Thank you
"""

html_message1 = """Hello 43c588,
<br><br>
This is a demo text snippet. It contains variables.<br>
So the mail body will be changed for each individual.
<br><br>
This message was sent to </i>872ab180</i>, aged <i>21</i><br> 
If you are not the recipient, reply to this email.
<br><br>
Thank you
"""

html_message2 = """Hello cc3198,
<br><br>
This is a demo text snippet. It contains variables.<br>
So the mail body will be changed for each individual.
<br><br>
This message was sent to </i>fb3b8ebf</i>, aged <i>35</i><br> 
If you are not the recipient, reply to this email.
<br><br>
Thank you
"""

html_message3 = """Hello 93ef0d,
<br><br>
This is a demo text snippet. It contains variables.<br>
So the mail body will be changed for each individual.
<br><br>
This message was sent to </i>b96f1bdb</i>, aged <i>21</i><br> 
If you are not the recipient, reply to this email.
<br><br>
Thank you
"""