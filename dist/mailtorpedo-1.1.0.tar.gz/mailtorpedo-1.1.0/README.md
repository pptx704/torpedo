<style>
    html {
        font-family: Trebuchet;
    }
</style>



<div style="align: center; text-align: center;">
    <img alt="GitHub" src="https://img.shields.io/github/license/pptx704/torpedo">
     <img alt="Travis" src="https://img.shields.io/travis/com/pptx704/torpedo">
    <img alt="Codecov" src="https://img.shields.io/codecov/c/github/pptx704/torpedo">
    <br>
    <img alt="License" src="https://img.shields.io/github/license/pptx704/torpedo">
    <img alt="Size" src="https://img.shields.io/github/repo-size/pptx704/torpedo">
	<br>
    <img alt="Contributors" src="https://img.shields.io/github/contributors/pptx704/torpedo">
    <img alt="Last Commit" src="https://img.shields.io/github/last-commit/pptx704/torpedo">
    <br>
    <img alt="Watchers" src="https://img.shields.io/github/watchers/pptx704/torpedo?style=social">
    <img alt="Stars" src="https://img.shields.io/github/stars/pptx704/torpedo?style=social">
</div>



<div style="align: center; text-align: center; font-family: Trebuchet;">
    <h1>
        Torpedo
    </h1>
    <div style="font-family: Trebuchet;">
        A Python package for sending personalized emails using own SMTP server.
    </div>
</div>

Hello
